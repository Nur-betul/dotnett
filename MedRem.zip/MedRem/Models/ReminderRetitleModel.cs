﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedRem.Models
{
    public class ReminderRetitleModel
    {
        public string? Title { get; set; }
        public Guid Id { get; set; }
    }
}
