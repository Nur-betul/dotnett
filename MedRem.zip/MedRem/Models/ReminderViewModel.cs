﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedRem.Models
{
    public class ReminderViewModel
    {
        public Entities.MedReminder? MedReminder { get; set; }
    }
}
